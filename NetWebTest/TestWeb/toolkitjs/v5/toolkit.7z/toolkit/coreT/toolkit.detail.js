﻿// --------------------------------
// Toolkit.detail
// --------------------------------
(function ($) {
    if (!$ || !window.Toolkit) return;
    // ----------------------------
    Toolkit.namespace('Toolkit.detail');

    $(document).ready(function () {
        $("body").bind("SelfUrl", Toolkit.data.getSelfUrl);
    });
})(jQuery);