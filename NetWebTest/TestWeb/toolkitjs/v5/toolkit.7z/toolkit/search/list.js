(function($) {
	$.extend(String.prototype, {
		'escapeReg': function() {
			return this.replace(new RegExp("([.*+?^=!:\x24{}()|[\\]\/\\\\])", "g"), '\\\x241');
		},
		'getQueryValue': function(name) {
			var reg = new RegExp("(^|&|\\?|#)" + name.escapeReg() + "=([^&]*)(&|\x24)", "");
			var match = this.match(reg);
   			return (match) ? match[2] : '';
		},
		'substitute': function(data) {
			if (data && typeof(data)=='object') {
				return this.replace(/\{([^{}]+)\}/g, function(match, key) {
					var value = data[key];
					return (value !== undefined) ? ''+value :'';
				});
			} else {
				return this.toString();
			}   
		}
	});
	// 绑定数据返回处理
	$.fn.bindSearchListClick = function() {
		if (this.size()==0) return;
		this.click(function() {
			var id = $(this).attr('dataId');
			var text = $(this).find('span').text();
			parent.Toolkit.ui.setEasySearchData({id:id, text:text});
			parent.Toolkit.util.dialog.close();
		});
	};
	// 查询表单处理
	$.fn.bindSearchFormEvent = function() {
		this.find('input').keydown(function(e) {
			try {
				var code=e.which||e.keyCode||0;
				if (code==13) {
					$(this).parent().prev().click();
				}
			} catch(err) {}
		});
		this.find('span.ico').click(function() {
			var text = $(this).next().find('input').val() || '';
			loadSearchData(text);
		});
	};
	// 加载搜索结果
	var loadSearchData = function(text) {
		var url = $('.pop-search').attr('dataUrl')||'';
		var param = '{"SELECT":[{"TYPE":"'+url.getQueryValue('Source')+'","VALUE":"'+text+'"}]}';
		$.ajax({
			type: 'post',
			url: url,
			data: param, 
			dataType: 'json', 
			success: function(d) {
				showSearchList(d);
			},
			error: function() {
				$('.pop-search-list').html('<div class="p20 tac red">数据读取失败</div>');
			}
		});
		$('.pop-search-list').html('<div class="txt-loading-32 mt30"></div>');
	};
	// 显示搜索列表
	var showSearchList = function(d) {
		var contentHtml = '<div class="p20 tac red">未找到数据</div>';
		if (d['EASY_SEARCH']) {
			items = d['EASY_SEARCH'];
			var htmlTemplate = '<li dataId="{CODE_VALUE}"><span>{CODE_NAME}</span>{CODEINFO}</li>';
			contentHtml = '<ul>';
			for (var i = 0; i < items.length; i++) {
				items[i]['CODEINFO'] = (items[i]['CODE_INFO'])?('('+items[i]['CODE_INFO']+')'):'';
				contentHtml += htmlTemplate.substitute(items[i]);
			}
			contentHtml += '</ul>';
		}
		$('.pop-search-list').html(contentHtml);
		$('.pop-search-list li').bindSearchListClick();
	};
	$(document).ready(function() {
		$('.pop-search').bindSearchFormEvent();
		$('.pop-search-list li').bindSearchListClick();
	});
})(jQuery);