(function ($) {
    $.extend(String.prototype, {
        'escapeReg': function () {
            return this.replace(new RegExp("([.*+?^=!:\x24{}()|[\\]\/\\\\])", "g"), '\\\x241');
        },
        'getQueryValue': function (name) {
            var reg = new RegExp("(^|&|\\?|#)" + name.escapeReg() + "=([^&]*)(&|\x24)", "");
            var match = this.match(reg);
            return (match) ? match[2] : '';
        },
        'substitute': function (data) {
            if (data && typeof (data) == 'object') {
                return this.replace(/\{([^{}]+)\}/g, function (match, key) {
                    var value = data[key];
                    return (value !== undefined) ? '' + value : '';
                });
            } else {
                return this.toString();
            }
        }
    });
    // 读取SubTree数据
    $.fn.loadSubTreeData = function (exId) {
        var element = this;
        element.html('<li>…加载中…</li>').addClass('dataloaded');
        element.siblings('.hitarea').addClass('placeholder');
        var parentId = element.parent().attr('dataId') ;//|| '-1';
        var url = $('#treeview').attr('dataUrl') || '';
        if (url && exId)
            url = url + '&' + $.param({ 'ExID': exId });
        $.ajax({
            type: 'get',
            url: url.substitute({ 'id': parentId }),
            dataType: 'json',
            success: function (d) {
                element.showSubTreeHtml(d);

                if (exId != '' && $('li[dataId=' + exId + ']').size() > 0) {
                    window.scrollTo(0, $('li[dataId=' + exId + ']').offset().top);
                    $('li[dataId=' + exId + ']>a').addClass('selected');
                }
            },
            error: function () {
                element.showSubTreeHtml();
            }
        });
    };
    // 显示SubTree
    $.fn.showSubTreeHtml = function (d) {
        var element = this;
        if (d) {
            if (d._TreeNode && d._TreeNode.length > 0) {
                var root = [], tempDict = {};
                var template = '<li dataId="{Id}" class="{status}"><a class="{type}">{Name}</a>{childElm}</li>';
                for (var i = 0; i < d._TreeNode.length; i++) {
                    var item = d._TreeNode[i];
                    item.status = (item['HasChildren']) ? 'closed' : '';
                    item.type = (item['HasChildren']) ? 'folder' : 'file';
                    item.childElm = (item['HasChildren']) ? '<ul></ul>' : '';
                    item.Node = $(template.substitute(item));

                    tempDict[item.Id] = item;
                    if (!tempDict[item.ParentId])
                        root.push(item);
                    else {
                        var parentItem = tempDict[item.ParentId];
                        parentItem.Node.removeClass('closed');
                        var tmp = parentItem.Node.children('ul');
                        if (tmp.length <= 0) tmp = $('<ul></ul>');
                        if (!tmp.hasClass('dataloaded')) tmp.addClass('dataloaded');
                        tmp.append(item.Node);
                    }
                }
                element.html('');
                for (var j = 0; j < root.length; j++) {
                    element.append(root[j].Node);
                }
                var branches = $(element, 'li');
                element.find('a').bindSearchListClick();
                element.treeview({
                    add: branches,
                    toggle: function () {
                        var elm = $(this);
                        if (elm.children('a').hasClass('file') || elm.children('ul').size() == 0) return;
                        if (elm.hasClass('collapsable') && !elm.children('ul').hasClass('dataloaded')) {
                            elm.children('ul').loadSubTreeData();
                        }
                    }
                });
            } else {
                element.html('没有子项');
            }
        } else {
            element.html('<li class="red">数据读取失败。<br><a href="#">请重试</a></li>');
            element.find('a').click(function () {
                element.loadSubTreeData();
                return false;
            });
        }
        element.siblings('.hitarea').removeClass('placeholder');
    };
    // 绑定返回处理
    $.fn.bindSearchListClick = function () {
        if (this.size() == 0) return;
        this.click(function () {
            var id = $(this).parent().attr('dataId');
            var text = $(this).text();
            parent.Toolkit.ui.setEasySearchData({ id: id, text: text });
            parent.Toolkit.util.dialog.close();
        });
    };
    // 初始数据列表处理
    $.fn.bindTreeViewUI = function () {
        this.find('a.folder').each(function () {
            if ($(this).siblings('ul').size() > 0) {
                $(this).siblings('ul').addClass('dataloaded');
                return;
            }
            $(this).parent().addClass('closed');
            $(this).after('<ul></ul>');
        });
        this.find('a').bindSearchListClick();
        this.treeview({
            persist: "location",
            toggle: function () {
                var element = $(this);
                if (element.children('a').hasClass('file') || element.children('ul').size() == 0) return;
                if (element.hasClass('collapsable') && !element.children('ul').hasClass('dataloaded')) {
                    element.children('ul').loadSubTreeData();
                }
            }
        });
    };
    $('#treeview').ready(function () {
        //var exId = document.location.href.getQueryValue('ExID');
        $('#treeview').bindTreeViewUI();
    });
})(jQuery);